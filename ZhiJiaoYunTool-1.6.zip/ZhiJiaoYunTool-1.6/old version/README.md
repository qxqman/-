<<<<<<< HEAD
=======
# 分析过程在上面的那个链接
>>>>>>> origin/master
# ZhiJiaoYunQianDao.py
职教云签到监控，一次登录几乎永久使用（获取的是app的接口和cookie）get_cookie
## get_cookie.py
获取登陆信息
## get_kecheng.py
获取当日课程情况
## autoqiandao.py
监控签到，如果签到成功一次，休息30分钟
## buqian.py
<<<<<<< HEAD
补签功能
=======
补签功能
## 已知Bug：
1.先运行一次get_cookie.py获取你的学生ID（当做密码使用的东西），在运行Main.py选择功能
>>>>>>> origin/master
